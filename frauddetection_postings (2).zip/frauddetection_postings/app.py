from flask import Flask, render_template, request, redirect, url_for, jsonify, session, flash,g
from flask_migrate import Migrate
from flask_cors import CORS
import joblib
import re
from collections import defaultdict
import time
import pandas as pd
import json
import os
import logging
from datetime import datetime, timedelta
import requests
from werkzeug.utils import secure_filename
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Import our modules
from models import db, User, AuditLog, FraudAlert, APIToken, EncryptedData
from security import init_security, authenticate_user, require_role, log_audit, validate_input, sanitize_input, check_rate_limit, detect_threats
from realtime import init_realtime, send_fraud_alert, send_dashboard_update, broadcast_system_status

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'your-super-secret-key-change-in-production')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///fraudguard.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'jwt-secret-key-change-in-production')
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Initialize extensions
db.init_app(app)
migrate = Migrate(app, db)
CORS(app)
init_security(app)
init_realtime(app)

# Load model and vectorizer
model = joblib.load('model.pkl')
vectorizer = joblib.load('vectorizer.pkl')

import pandas as pd
import logging
import os
import random

logger = logging.getLogger(__name__)

csv_path = 'dataset/fake_job_postings.csv'

if os.path.exists(csv_path):
    df = pd.read_csv(csv_path)
    logger.info(f"CSV loaded successfully! Total rows: {len(df)}")
else:
    logger.warning("CSV not found! Using dummy data for dashboard.")
    # Create dummy DataFrame
    df = pd.DataFrame({
        'title': [f'Job {i}' for i in range(1, 21)],
        'company_profile': [f'Company {i}' for i in range(1, 21)],
        'location': [f'City {i}, Country {i%5}' for i in range(1, 21)],
        'employment_type': [random.choice(['Full-time', 'Part-time', 'Contract']) for _ in range(20)],
        'department': [random.choice(['IT', 'HR', 'Sales', 'Marketing']) for _ in range(20)],
        'fraudulent': [random.choice([0, 1]) for _ in range(20)]
    })
print(df.columns)


# Simple rate limiting: max 10 requests per minute per IP
rate_limit = defaultdict(list)

def is_rate_limited(ip):
    now = time.time()
    rate_limit[ip] = [t for t in rate_limit[ip] if now - t < 60]
    if len(rate_limit[ip]) >= 10:
        return True
    rate_limit[ip].append(now)
    return False

def preprocess_text(text):
    if not text:
        return ""
    text = re.sub(r'\W', ' ', str(text))
    text = text.lower()
    # Simple stop words removal (basic, since nltk may not be loaded in app)
    stop_words = set(['i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', "you're", "you've", "you'll", "you'd", 'your', 'yours', 'yourself', 'yourselves', 'he', 'him', 'his', 'himself', 'she', "she's", 'her', 'hers', 'herself', 'it', "it's", 'its', 'itself', 'they', 'them', 'their', 'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', "that'll", 'these', 'those', 'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just', 'don', "don't", 'should', "should've", 'now', 'd', 'll', 'm', 'o', 're', 've', 'y', 'ain', 'aren', "aren't", 'couldn', "couldn't", 'didn', "didn't", 'doesn', "doesn't", 'hadn', "hadn't", 'hasn', "hasn't", 'haven', "haven't", 'isn', "isn't", 'ma', 'mightn', "mightn't", 'mustn', "mustn't", 'needn', "needn't", 'shan', "shan't", 'shouldn', "shouldn't", 'wasn', "wasn't", 'weren', "weren't", 'won', "won't", 'wouldn', "wouldn't"])
    text = ' '.join([word for word in text.split() if word not in stop_words])
    return text

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/analyze', methods=['GET', 'POST'])
def analyze():
    if request.method == 'POST':
        ip = request.remote_addr
        if is_rate_limited(ip):
            return "Rate limit exceeded. Try again later.", 429

        title = request.form.get('title', '')
        description = request.form.get('description', '')
        requirements = request.form.get('requirements', '')
        company_profile = request.form.get('company_profile', '')

        # Basic input validation: check length and no scripts
        if len(title) > 500 or len(description) > 5000 or len(requirements) > 5000 or len(company_profile) > 5000:
            return "Input too long.", 400
        if re.search(r'<script', title + description + requirements + company_profile, re.IGNORECASE):
            return "Invalid input.", 400

        combined_text = title + ' ' + description + ' ' + requirements + ' ' + company_profile
        processed = preprocess_text(combined_text)
        vec = vectorizer.transform([processed])
        prediction = model.predict(vec)[0]
        probability = model.predict_proba(vec)[0][1]  # Probability of fraudulent

        return render_template('results.html', prediction=prediction, probability=probability)
    return render_template('analyze.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/stats')
def stats():
    insights = {}
    if df is not None:
        # Job types distribution
        job_types = df['title'].value_counts().head(10).to_dict()
        insights['job_types'] = job_types

        # Location distribution
        locations = df['location'].value_counts().head(10).to_dict()
        insights['locations'] = locations

        # Fraud by employment type
        fraud_by_type = df[df['fraudulent'] == 1]['employment_type'].value_counts().to_dict()
        insights['fraud_by_type'] = fraud_by_type

        # Total jobs
        total_jobs = len(df)
        fraudulent_jobs = df['fraudulent'].sum()
        insights['total_jobs'] = total_jobs
        insights['fraudulent_jobs'] = fraudulent_jobs

    return render_template('stats.html', insights=insights)

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/harm')
def harm():
    return render_template('harm.html')

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html')

    # Unique feature: User dashboard with personalized insights
    insights = {}
    stats = {}
    if df is not None:
        insights['total_scanned'] = len(df)
        insights['fraud_rate'] = (df['fraudulent'].sum() / len(df)) * 100
        insights['top_fraud_locations'] = df[df['fraudulent'] == 1]['location'].value_counts().head(5).to_dict()
        insights['fraud_by_department'] = df[df['fraudulent'] == 1]['department'].value_counts().head(5).to_dict()
        insights['legitimate_vs_fraudulent'] = {
            'legitimate': len(df[df['fraudulent'] == 0]),
            'fraudulent': len(df[df['fraudulent'] == 1])
        }

        # Parse countries from locations (simplified: take last part after comma)
        def extract_country(location):
            if pd.isna(location):
                return 'Unknown'
            parts = str(location).split(',')
            return parts[-1].strip() if len(parts) > 1 else 'Unknown'

        df['country'] = df['location'].apply(extract_country)
        fraud_by_country = df[df['fraudulent'] == 1]['country'].value_counts().head(10).to_dict()
        insights['fraud_by_country'] = fraud_by_country

        # Fraud by employment type
        fraud_by_type = df[df['fraudulent'] == 1]['employment_type'].value_counts().to_dict()
        insights['fraud_by_type'] = fraud_by_type

        # Simulate fraud trends (monthly data)
        import random
        months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
        fraud_trends = [random.randint(10, 50) for _ in months]
        insights['fraud_trends'] = {'labels': months, 'data': fraud_trends}

        # Risk levels
        insights['risk_levels'] = {
            'low': len(df[df['fraudulent'] == 0]) * 0.7,
            'medium': len(df[df['fraudulent'] == 0]) * 0.2,
            'high': len(df[df['fraudulent'] == 1])
        }

        # Stats for dashboard cards
        stats['total_scans'] = len(df)
        stats['fraud_detected'] = df['fraudulent'].sum()
        stats['accuracy_rate'] = 95  # Placeholder for model accuracy
        stats['last_scan'] = '2 hours ago'  # Placeholder

    return render_template('dashboard.html', insights=insights, stats=stats)

@app.route('/countries')
def countries():
    import pandas as pd

    # Load dataset
    df = pd.read_csv('fake_job_postings.csv')

    # Clean data
    df['country'] = df['location'].fillna('Unknown')
    df['fraudulent'] = df['fraudulent'].fillna(0)

    # ---------- TOP COUNTRIES ----------
    country_stats = (
        df.groupby('country')
        .agg(
            total_jobs=('fraudulent', 'count'),
            fraud_jobs=('fraudulent', 'sum')
        )
        .reset_index()
    )

    country_stats['fraud_rate'] = (
        country_stats['fraud_jobs'] / country_stats['total_jobs'] * 100
    ).round(2)

    country_stats = country_stats.sort_values(
        by='fraud_rate', ascending=False
    ).head(10)

    country_data = []
    for _, row in country_stats.iterrows():
        country_data.append({
            "country": str(row['country']),
            "total_jobs": int(row['total_jobs']),
            "fraud_jobs": int(row['fraud_jobs']),
            "fraud_rate": float(row['fraud_rate'])
        })

    # ---------- INDIA STATS ----------
    india_df = df[df['country'].str.contains('India', case=False, na=False)]

    india_total_jobs = int(len(india_df))
    india_fraud_jobs = int(india_df['fraudulent'].sum())

    india_fraud_rate = (
        (india_fraud_jobs / india_total_jobs) * 100
        if india_total_jobs > 0 else 0
    )

    india_stats = {
        "total_jobs": india_total_jobs,
        "fraud_jobs": india_fraud_jobs,
        "fraud_rate": round(float(india_fraud_rate), 2)
    }

    # Render page
    return render_template(
        'countries.html',
        country_data=country_data,
        india_stats=india_stats
    )



@app.route('/laws')
def laws():
    return render_template('laws.html')

@app.route('/report', methods=['GET', 'POST'])
def report():
    if request.method == 'POST':
        job_title = request.form.get('job_title', '')
        job_url = request.form.get('job_url', '')
        description = request.form.get('description', '')
        reporter_email = request.form.get('reporter_email', '')

        # Basic validation
        if not job_title or not description:
            return "Job title and description are required.", 400

        report_data = {
            'job_title': job_title,
            'job_url': job_url,
            'description': description,
            'reporter_email': reporter_email,
            'timestamp': time.time(),
            'ip': request.remote_addr
        }

        # Load existing reports
        reports = []
        if os.path.exists('reports.json'):
            try:
                with open('reports.json', 'r') as f:
                    reports = json.load(f)
            except:
                reports = []

        # Add new report
        reports.append(report_data)

        # Save reports
        with open('reports.json', 'w') as f:
            json.dump(reports, f, indent=2)

        return render_template('report_success.html')
    return render_template('report.html')

# Authentication routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        # Simple demo authentication (in production, use proper auth)
        if username == 'admin' and password == 'password':
            session['user'] = username
            return redirect(url_for('dashboard'))
        return render_template('login.html', error='Invalid credentials')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return render_template('logout.html')


# API endpoints for data export
@app.route('/api/insights')
def api_insights():
    insights = {}
    if df is not None:
        insights['total_scanned'] = len(df)
        insights['fraud_rate'] = (df['fraudulent'].sum() / len(df)) * 100
        insights['top_fraud_locations'] = df[df['fraudulent'] == 1]['location'].value_counts().head(5).to_dict()
    return jsonify(insights)

@app.route('/api/export/csv')
def export_csv():
    if df is not None:
        csv_data = df.to_csv(index=False)
        return csv_data, 200, {'Content-Type': 'text/csv', 'Content-Disposition': 'attachment; filename=fraud_data.csv'}
    return 'No data available', 404

@app.route('/api/stats')
def api_stats():
    if df is not None:
        total_jobs_scanned = len(df)
        fake_jobs_detected = df['fraudulent'].sum()
        safe_jobs_count = total_jobs_scanned - fake_jobs_detected
        reported_companies = len(df[df['fraudulent'] == 1]['company_profile'].unique())
        return jsonify({
            'totalJobsScanned': total_jobs_scanned,
            'fakeJobsDetected': int(fake_jobs_detected),
            'safeJobsCount': safe_jobs_count,
            'reportedCompanies': reported_companies
        })
    return jsonify({'error': 'No data available'}), 404

@app.route('/api/jobs')
def api_jobs():
    if df is not None:
        jobs = []
        for index, row in df.head(10).iterrows():
            jobs.append({
                'id': int(index),
                'title': str(row['title']),
                'company': str(row['company_profile'][:50]) if pd.notna(row['company_profile']) else 'Unknown',
                'location': str(row['location']) if pd.notna(row['location']) else 'Unknown',
                'fraudulent': bool(row['fraudulent'])
            })
        return jsonify(jobs)
    return jsonify({'error': 'No data available'}), 404

@app.route('/api/reports')
def api_reports():
    if df is not None:
        reports = []
        fraud_df = df[df['fraudulent'] == 1].head(10)
        for index, row in fraud_df.iterrows():
            reports.append({
                'id': int(index),
                'jobTitle': str(row['title']),
                'company': str(row['company_profile'][:50]) if pd.notna(row['company_profile']) else 'Unknown',
                'location': str(row['location']) if pd.notna(row['location']) else 'Unknown',
                'reportedAt': '2024-01-01'  # Mock date
            })
        return jsonify(reports)
    return jsonify({'error': 'No data available'}), 404

@app.route('/api/trends')
def api_trends():
    if df is not None:
        # Simulate monthly fraud trends (in a real app, this would be from database)
        import random
        months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        fraud_trends = [random.randint(10, 50) for _ in months]
        return jsonify({'labels': months, 'data': fraud_trends})
    return jsonify({'error': 'No data available'}), 404

@app.route('/api/alerts')
def api_alerts():
    # Mock alerts data (in a real app, from database)
    alerts = [
        {'id': 1, 'job_title': 'Software Engineer', 'company': 'Tech Corp', 'risk_score': 0.85, 'status': 'active'},
        {'id': 2, 'job_title': 'Marketing Manager', 'company': 'Ad Agency', 'risk_score': 0.92, 'status': 'active'},
        {'id': 3, 'job_title': 'Data Analyst', 'company': 'Data Inc', 'risk_score': 0.78, 'status': 'resolved'}
    ]
    return jsonify({'alerts': alerts})

# Job comparison tool
@app.route('/compare', methods=['GET', 'POST'])
def compare():
    if request.method == 'POST':
        job1_title = request.form.get('job1_title', '')
        job1_desc = request.form.get('job1_description', '')
        job2_title = request.form.get('job2_title', '')
        job2_desc = request.form.get('job2_description', '')

        # Analyze both jobs
        results = {}
        for i, (title, desc) in enumerate([(job1_title, job1_desc), (job2_title, job2_desc)], 1):
            if title and desc:
                combined_text = title + ' ' + desc
                processed = preprocess_text(combined_text)
                vec = vectorizer.transform([processed])
                prediction = model.predict(vec)[0]
                probability = model.predict_proba(vec)[0][1]
                results[f'job{i}'] = {'prediction': prediction, 'probability': probability}

        return render_template('compare.html', results=results, job1_title=job1_title, job2_title=job2_title)
    return render_template('compare.html')

@app.route('/tools')
def tools():
    return render_template('tools.html')

@app.route('/news')
def news():
    return render_template('news.html')

@app.route('/community')
def community():
    return render_template('community.html')

@app.route('/batch_analyze', methods=['POST'])
def batch_analyze():
    if 'batchFile' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    file = request.files['batchFile']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    if not file.filename.endswith('.csv'):
        return jsonify({'error': 'Invalid file type'}), 400
    try:
        df_batch = pd.read_csv(file)
    except Exception as e:
        return jsonify({'error': 'Error reading CSV'}), 400
    results = []
    for index, row in df_batch.iterrows():
        title = str(row.get('title', ''))
        description = str(row.get('description', ''))
        requirements = str(row.get('requirements', ''))
        company_profile = str(row.get('company_profile', ''))
        combined_text = title + ' ' + description + ' ' + requirements + ' ' + company_profile
        processed = preprocess_text(combined_text)
        vec = vectorizer.transform([processed])
        prediction = model.predict(vec)[0]
        probability = model.predict_proba(vec)[0][1]
        results.append({
            'title': title,
            'prediction': 'fraudulent' if prediction == 1 else 'legitimate',
            'probability': float(probability)
        })
    email = request.form.get('emailNotification')
    if email:
        subject = 'Batch Analysis Results'
        body = f'Batch analysis completed. {len(results)} jobs analyzed. Results attached or summarized.'
        send_email_notification(email, subject, body)
    return jsonify({'results': results, 'total': len(results)})

# Enhanced Authentication Routes
@app.route('/api/auth/login', methods=['POST'])
def api_login():
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400

    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400

    # Threat detection
    threats = detect_threats(data)
    if threats:
        log_audit(None, 'threat_detected', 'login', f'Threats: {threats}')
        return jsonify({'error': 'Suspicious activity detected'}), 400

    token, error = authenticate_user(username, password)
    if error:
        return jsonify({'error': error}), 401

    return jsonify({'access_token': token, 'token_type': 'Bearer'})

@app.route('/api/auth/register', methods=['POST'])
def api_register():
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400

    # Validation rules
    validation_rules = {
        'username': {'required': True, 'min_length': 3, 'max_length': 50},
        'email': {'required': True, 'type': 'email', 'max_length': 120},
        'password': {'required': True, 'min_length': 8}
    }

    errors = validate_input(data, validation_rules)
    if errors:
        return jsonify({'error': 'Validation failed', 'details': errors}), 400

    # Check if user exists
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'error': 'Username already exists'}), 409

    if User.query.filter_by(email=data['email']).first():
        return jsonify({'error': 'Email already exists'}), 409

    # Create user
    user = User(username=data['username'], email=data['email'])
    user.set_password(data['password'])
    db.session.add(user)
    db.session.commit()

    log_audit(user.id, 'user_registered', 'registration', 'New user registration')

    return jsonify({'message': 'User created successfully'}), 201

@app.route('/api/auth/profile', methods=['GET'])
@require_role('user', 'analyst', 'admin')
def get_profile():
    from flask_jwt_extended import get_jwt_identity
    user_id = get_jwt_identity()
    user = User.query.get(user_id)

    if not user:
        return jsonify({'error': 'User not found'}), 404

    return jsonify({
        'id': user.id,
        'username': user.username,
        'email': user.email,
        'role': user.role,
        'created_at': user.created_at.isoformat(),
        'last_login': user.last_login.isoformat() if user.last_login else None
    })

# Enhanced API Endpoints
@app.route('/api/v1/analyze', methods=['POST'])
@require_role('user', 'analyst', 'admin')
def api_analyze():
    from flask_jwt_extended import get_jwt_identity
    user_id = get_jwt_identity()

    # Rate limiting check
    if not check_rate_limit(user_id, 'analyze'):
        return jsonify({'error': 'Rate limit exceeded'}), 429

    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400

    # Sanitize input
    for key in data:
        if isinstance(data[key], str):
            data[key] = sanitize_input(data[key])

    # Threat detection
    threats = detect_threats(data)
    if threats:
        log_audit(user_id, 'threat_detected', 'analyze', f'Threats: {threats}')
        return jsonify({'error': 'Suspicious content detected'}), 400

    title = data.get('title', '')
    description = data.get('description', '')
    requirements = data.get('requirements', '')
    company_profile = data.get('company_profile', '')

    # Enhanced validation
    validation_rules = {
        'title': {'max_length': 500},
        'description': {'max_length': 5000},
        'requirements': {'max_length': 5000},
        'company_profile': {'max_length': 5000}
    }

    errors = validate_input(data, validation_rules)
    if errors:
        return jsonify({'error': 'Validation failed', 'details': errors}), 400

    combined_text = title + ' ' + description + ' ' + requirements + ' ' + company_profile
    processed = preprocess_text(combined_text)
    vec = vectorizer.transform([processed])
    prediction = model.predict(vec)[0]
    probability = model.predict_proba(vec)[0][1]

    # Log analysis
    log_audit(user_id, 'job_analyzed', 'analysis', f'Prediction: {prediction}, Probability: {probability:.3f}')

    # Check for high-risk fraud and create alert
    if prediction == 1 and probability > 0.8:
        alert = FraudAlert(
            job_title=title,
            company=company_profile.split('.')[0] if company_profile else 'Unknown',
            location=data.get('location', 'Unknown'),
            risk_score=float(probability),
            alert_type='high_risk'
        )
        db.session.add(alert)
        db.session.commit()

        # Send real-time alert
        send_fraud_alert({
            'id': alert.id,
            'job_title': alert.job_title,
            'company': alert.company,
            'location': alert.location,
            'risk_score': alert.risk_score,
            'alert_type': alert.alert_type
        })

    return jsonify({
        'prediction': 'fraudulent' if prediction == 1 else 'legitimate',
        'probability': float(probability),
        'confidence': 'high' if probability > 0.8 else 'medium' if probability > 0.6 else 'low'
    })

@app.route('/api/v1/dashboard/stats', methods=['GET'])
@require_role('user', 'analyst', 'admin')
def api_dashboard_stats():
    from flask_jwt_extended import get_jwt_identity
    user_id = get_jwt_identity()
    user = User.query.get(user_id)

    # Get real-time stats
    stats = get_live_stats()

    # Add user-specific data
    user_alerts = FraudAlert.query.filter_by(assigned_to=user_id, status='active').count()
    stats['user_alerts'] = user_alerts

    return jsonify(stats)

@app.route('/api/v1/alerts', methods=['GET'])
@require_role('analyst', 'admin')
def get_alerts():
    from flask_jwt_extended import get_jwt_identity
    user_id = get_jwt_identity()
    user = User.query.get(user_id)

    # Role-based filtering
    if user.role == 'analyst':
        alerts = FraudAlert.query.filter_by(assigned_to=user_id).all()
    else:  # admin
        alerts = FraudAlert.query.all()

    alerts_data = []
    for alert in alerts:
        alerts_data.append({
            'id': alert.id,
            'job_title': alert.job_title,
            'company': alert.company,
            'location': alert.location,
            'risk_score': alert.risk_score,
            'alert_type': alert.alert_type,
            'status': alert.status,
            'created_at': alert.created_at.isoformat(),
            'assigned_to': alert.assigned_to
        })

    return jsonify({'alerts': alerts_data})

@app.route('/api/v1/alerts/<int:alert_id>/resolve', methods=['POST'])
@require_role('analyst', 'admin')
def resolve_alert(alert_id):
    from flask_jwt_extended import get_jwt_identity
    user_id = get_jwt_identity()

    alert = FraudAlert.query.get(alert_id)
    if not alert:
        return jsonify({'error': 'Alert not found'}), 404

    # Check permissions
    if alert.assigned_to != user_id:
        user = User.query.get(user_id)
        if user.role != 'admin':
            return jsonify({'error': 'Not authorized to resolve this alert'}), 403

    alert.status = 'resolved'
    alert.resolved_at = datetime.utcnow()
    db.session.commit()

    log_audit(user_id, 'alert_resolved', 'alert_management', f'Resolved alert {alert_id}')

    return jsonify({'message': 'Alert resolved successfully'})

# User Management (Admin only)
@app.route('/api/v1/users', methods=['GET'])
@require_role('admin')
def get_users():
    users = User.query.all()
    users_data = []
    for user in users:
        users_data.append({
            'id': user.id,
            'username': user.username,
            'email': user.email,
            'role': user.role,
            'is_active': user.is_active,
            'created_at': user.created_at.isoformat(),
            'last_login': user.last_login.isoformat() if user.last_login else None
        })

    return jsonify({'users': users_data})

@app.route('/api/v1/users/<int:user_id>/role', methods=['PUT'])
@require_role('admin')
def update_user_role(user_id):
    from flask_jwt_extended import get_jwt_identity
    current_user_id = get_jwt_identity()

    data = request.get_json()
    new_role = data.get('role')

    if new_role not in ['user', 'analyst', 'admin']:
        return jsonify({'error': 'Invalid role'}), 400

    user = User.query.get(user_id)
    if not user:
        return jsonify({'error': 'User not found'}), 404

    old_role = user.role
    user.role = new_role
    db.session.commit()

    log_audit(current_user_id, 'role_updated', 'user_management', f'Changed role for user {user_id} from {old_role} to {new_role}')

    return jsonify({'message': 'User role updated successfully'})

# Audit Logging
@app.route('/api/v1/audit/logs', methods=['GET'])
@require_role('admin')
def get_audit_logs():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)

    logs = AuditLog.query.order_by(AuditLog.timestamp.desc()).paginate(page=page, per_page=per_page)

    logs_data = []
    for log in logs.items:
        logs_data.append({
            'id': log.id,
            'user_id': log.user_id,
            'action': log.action,
            'resource': log.resource,
            'details': log.details,
            'ip_address': log.ip_address,
            'severity': log.severity,
            'timestamp': log.timestamp.isoformat()
        })

    return jsonify({
        'logs': logs_data,
        'total': logs.total,
        'pages': logs.pages,
        'current_page': page
    })

# Utility functions
def get_live_stats():
    """Get live statistics for dashboard"""
    stats = {}

    if df is not None:
        stats['total_scanned'] = len(df)
        stats['fraud_rate'] = (df['fraudulent'].sum() / len(df)) * 100
        stats['active_alerts'] = FraudAlert.query.filter_by(status='active').count()
        stats['resolved_alerts'] = FraudAlert.query.filter_by(status='resolved').count()
        stats['total_users'] = User.query.count()
        stats['system_health'] = 'good'  # Placeholder

    return stats

# Email notifications
def send_email_notification(to_email, subject, body):
    """Send email notification"""
    try:
        msg = MIMEMultipart()
        msg['From'] = os.getenv('SMTP_FROM', 'noreply@fraudguard.com')
        msg['To'] = to_email
        msg['Subject'] = subject

        msg.attach(MIMEText(body, 'html'))

        server = smtplib.SMTP(os.getenv('SMTP_SERVER', 'smtp.gmail.com'), int(os.getenv('SMTP_PORT', 587)))
        server.starttls()
        server.login(os.getenv('SMTP_USER'), os.getenv('SMTP_PASS'))
        server.send_message(msg)
        server.quit()

        return True
    except Exception as e:
        logger.error(f"Failed to send email: {e}")
        return False

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500

# Before request middleware
@app.before_request
def before_request():
    g.start_time = time.time()

@app.after_request
def after_request(response):
    if hasattr(g, 'start_time'):
        duration = time.time() - g.start_time
        logger.info(f"Request {request.path} took {duration:.3f}s")
    return response

if __name__ == '__main__':
    # Create database tables
    with app.app_context():
        db.create_all()

        # Create default admin user if not exists
        if not User.query.filter_by(username='admin').first():
            admin = User(username='admin', email='admin@fraudguard.com', role='admin')
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()

    app.run(debug=True)
