from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from flask import request, jsonify, current_app
from models import db, User, AuditLog
from functools import wraps
import logging
from datetime import datetime, timedelta
import re

jwt = JWTManager()

def init_security(app):
    jwt.init_app(app)

def log_audit(user_id, action, resource=None, details=None, severity='info'):
    """Log audit events"""
    try:
        ip = request.remote_addr if request else 'system'
        audit_log = AuditLog(
            user_id=user_id,
            action=action,
            resource=resource,
            details=details,
            ip_address=ip,
            severity=severity
        )
        db.session.add(audit_log)
        db.session.commit()
    except Exception as e:
        logging.error(f"Failed to log audit event: {e}")

def require_role(*roles):
    """Decorator to require specific roles"""
    def decorator(f):
        @wraps(f)
        @jwt_required()
        def decorated_function(*args, **kwargs):
            current_user_id = get_jwt_identity()
            user = User.query.get(current_user_id)

            if not user or user.role not in roles:
                return jsonify({'error': 'Insufficient permissions'}), 403

            return f(*args, **kwargs)
        return decorated_function
    return decorator

def authenticate_user(username, password):
    """Authenticate user and return access token"""
    user = User.query.filter_by(username=username).first()

    if not user:
        return None, 'User not found'

    if user.is_locked():
        return None, 'Account is locked'

    if not user.check_password(password):
        user.failed_attempts += 1
        if user.failed_attempts >= 5:
            user.locked_until = datetime.utcnow() + timedelta(minutes=30)
        db.session.commit()
        return None, 'Invalid credentials'

    # Reset failed attempts on successful login
    user.failed_attempts = 0
    user.last_login = datetime.utcnow()
    db.session.commit()

    # Log successful login
    log_audit(user.id, 'login', 'authentication', 'Successful login')

    # Create access token
    access_token = create_access_token(identity=user.id, expires_delta=timedelta(hours=1))

    return access_token, None

def validate_input(data, rules):
    """Validate input data against rules"""
    errors = []

    for field, rule in rules.items():
        value = data.get(field, '')

        if rule.get('required') and not value:
            errors.append(f"{field} is required")
            continue

        if 'min_length' in rule and len(str(value)) < rule['min_length']:
            errors.append(f"{field} must be at least {rule['min_length']} characters")

        if 'max_length' in rule and len(str(value)) > rule['max_length']:
            errors.append(f"{field} must be at most {rule['max_length']} characters")

        if 'pattern' in rule and not re.match(rule['pattern'], str(value)):
            errors.append(f"{field} format is invalid")

        if 'type' in rule:
            try:
                if rule['type'] == 'email':
                    # Basic email validation
                    if '@' not in value or '.' not in value:
                        errors.append(f"{field} must be a valid email")
                elif rule['type'] == 'int':
                    int(value)
                elif rule['type'] == 'float':
                    float(value)
            except ValueError:
                errors.append(f"{field} must be of type {rule['type']}")

    return errors

def sanitize_input(text):
    """Sanitize user input to prevent XSS"""
    if not text:
        return text

    # Remove script tags
    text = re.sub(r'<script[^>]*>.*?</script>', '', text, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r'<script[^>]*>', '', text, flags=re.IGNORECASE)

    # Remove other dangerous tags
    dangerous_tags = ['iframe', 'object', 'embed', 'form', 'input', 'button']
    for tag in dangerous_tags:
        text = re.sub(rf'<{tag}[^>]*>.*?</{tag}>', '', text, flags=re.IGNORECASE | re.DOTALL)
        text = re.sub(rf'<{tag}[^>]*>', '', text, flags=re.IGNORECASE)

    return text

def check_rate_limit(user_id, action, limit=100, window_minutes=60):
    """Check if user has exceeded rate limit"""
    window_start = datetime.utcnow() - timedelta(minutes=window_minutes)

    count = AuditLog.query.filter(
        AuditLog.user_id == user_id,
        AuditLog.action == action,
        AuditLog.timestamp >= window_start
    ).count()

    return count < limit

def detect_threats(data):
    """Basic threat detection"""
    threats = []

    # Check for SQL injection patterns
    sql_patterns = [r'union.*select', r';.*--', r'/\*.*\*/', r'xp_cmdshell', r'exec.*master']
    for pattern in sql_patterns:
        if re.search(pattern, str(data), re.IGNORECASE):
            threats.append('potential_sql_injection')

    # Check for XSS patterns
    xss_patterns = [r'<script', r'javascript:', r'on\w+\s*=', r'eval\s*\(']
    for pattern in xss_patterns:
        if re.search(pattern, str(data), re.IGNORECASE):
            threats.append('potential_xss')

    # Check for suspicious keywords
    suspicious_keywords = ['admin', 'password', 'drop table', 'select * from']
    for keyword in suspicious_keywords:
        if keyword.lower() in str(data).lower():
            threats.append('suspicious_keyword')

    return threats

@jwt.user_identity_loader
def user_identity_lookup(user):
    return user.id

@jwt.user_lookup_loader
def user_lookup_callback(_jwt_header, jwt_data):
    identity = jwt_data["sub"]
    return User.query.get(identity)
