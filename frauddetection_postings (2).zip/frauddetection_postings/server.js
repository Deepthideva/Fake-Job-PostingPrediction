const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Mock data for APIs
const mockStats = {
  totalJobsScanned: 17880,
  fakeJobsDetected: 866,
  safeJobsCount: 17014,
  reportedCompanies: 452
};

const mockJobs = [
  { id: 1, title: 'Software Engineer', company: 'TechCorp', location: 'New York', fraudulent: false },
  { id: 2, title: 'Data Analyst', company: 'FakeJobs Inc', location: 'California', fraudulent: true },
  { id: 3, title: 'Marketing Manager', company: 'Global Marketing', location: 'Texas', fraudulent: false }
];

const mockReports = [
  { id: 1, jobTitle: 'Fake Job 1', company: 'ScamCo', location: 'Unknown', reportedAt: '2024-01-01' },
  { id: 2, jobTitle: 'Fake Job 2', company: 'Fraudulent Ltd', location: 'Online', reportedAt: '2024-01-02' }
];

// API endpoints
app.get('/api/stats', (req, res) => {
  res.json(mockStats);
});

app.get('/api/jobs', (req, res) => {
  res.json(mockJobs);
});

app.get('/api/reports', (req, res) => {
  res.json(mockReports);
});

app.listen(port, () => {
  console.log(`Node.js server running at http://localhost:${port}`);
});
