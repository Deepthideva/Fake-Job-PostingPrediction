from flask_socketio import SocketIO, emit, join_room, leave_room
from flask import request
from models import db, FraudAlert, User
from security import log_audit
import json
from datetime import datetime

socketio = SocketIO(cors_allowed_origins="*")

def init_realtime(app):
    socketio.init_app(app, async_mode='threading')

@socketio.on('connect')
def handle_connect():
    print('Client connected')
    emit('status', {'message': 'Connected to FraudGuard Real-time Service'})

@socketio.on('disconnect')
def handle_disconnect():
    print('Client disconnected')

@socketio.on('join_dashboard')
def handle_join_dashboard(data):
    """Join dashboard room for real-time updates"""
    user_id = data.get('user_id')
    if user_id:
        join_room(f'dashboard_{user_id}')
        emit('status', {'message': f'Joined dashboard room for user {user_id}'})

@socketio.on('leave_dashboard')
def handle_leave_dashboard(data):
    """Leave dashboard room"""
    user_id = data.get('user_id')
    if user_id:
        leave_room(f'dashboard_{user_id}')
        emit('status', {'message': f'Left dashboard room for user {user_id}'})

@socketio.on('subscribe_alerts')
def handle_subscribe_alerts(data):
    """Subscribe to fraud alerts"""
    user_id = data.get('user_id')
    alert_types = data.get('alert_types', ['high_risk', 'suspicious'])
    if user_id:
        join_room(f'alerts_{user_id}')
        emit('status', {'message': f'Subscribed to alerts: {alert_types}'})

def send_fraud_alert(alert_data):
    """Send fraud alert to subscribed users"""
    alert = {
        'id': alert_data.get('id'),
        'job_title': alert_data.get('job_title'),
        'company': alert_data.get('company'),
        'location': alert_data.get('location'),
        'risk_score': alert_data.get('risk_score'),
        'alert_type': alert_data.get('alert_type'),
        'timestamp': datetime.utcnow().isoformat()
    }

    # Send to all admin and analyst users
    admin_users = User.query.filter(User.role.in_(['admin', 'analyst'])).all()
    for user in admin_users:
        socketio.emit('fraud_alert', alert, room=f'alerts_{user.id}')

    # Also send to dashboard rooms
    for user in admin_users:
        socketio.emit('dashboard_update', {
            'type': 'new_alert',
            'data': alert
        }, room=f'dashboard_{user.id}')

def send_dashboard_update(user_id, update_type, data):
    """Send dashboard update to specific user"""
    socketio.emit('dashboard_update', {
        'type': update_type,
        'data': data,
        'timestamp': datetime.utcnow().isoformat()
    }, room=f'dashboard_{user_id}')

def broadcast_system_status(status_data):
    """Broadcast system status to all connected clients"""
    socketio.emit('system_status', {
        'status': status_data,
        'timestamp': datetime.utcnow().isoformat()
    })

@socketio.on('request_live_stats')
def handle_live_stats_request(data):
    """Provide live statistics"""
    user_id = data.get('user_id')
    if user_id:
        # Get real-time stats (simplified example)
        from app import get_live_stats
        stats = get_live_stats()
        emit('live_stats', stats)

@socketio.on('mark_alert_read')
def handle_mark_alert_read(data):
    """Mark alert as read"""
    alert_id = data.get('alert_id')
    user_id = data.get('user_id')

    if alert_id and user_id:
        alert = FraudAlert.query.get(alert_id)
        if alert and alert.assigned_to == user_id:
            alert.status = 'resolved'
            alert.resolved_at = datetime.utcnow()
            db.session.commit()
            log_audit(user_id, 'resolve_alert', 'fraud_alert', f'Resolved alert {alert_id}')
            emit('alert_updated', {'alert_id': alert_id, 'status': 'resolved'})

@socketio.on('send_message')
def handle_send_message(data):
    """Handle real-time messaging between users"""
    sender_id = data.get('sender_id')
    receiver_id = data.get('receiver_id')
    message = data.get('message')

    if sender_id and receiver_id and message:
        message_data = {
            'sender_id': sender_id,
            'receiver_id': receiver_id,
            'message': message,
            'timestamp': datetime.utcnow().isoformat()
        }

        # Send to receiver's room
        socketio.emit('new_message', message_data, room=f'user_{receiver_id}')

        # Confirm to sender
        emit('message_sent', {'status': 'sent'})

def notify_model_update(model_info):
    """Notify about model updates"""
    notification = {
        'type': 'model_update',
        'model_name': model_info.get('name'),
        'accuracy': model_info.get('accuracy'),
        'timestamp': datetime.utcnow().isoformat()
    }

    # Send to all admin users
    admin_users = User.query.filter_by(role='admin').all()
    for user in admin_users:
        socketio.emit('notification', notification, room=f'dashboard_{user.id}')
